// Cuando no tenemos una base de datos intuitiva podemos crear la tabla con codigo SQL
// Primero se crea la base de datos.
CREATE DATABASE php_mysql_crud;

use php_mysql_crud;
// creamos con el metodo CREATE la tabla 
CREATE TABLE tempdia(
  // Especificamos cada una de las columnas 
  id INT(11) PRIMARY KEY AUTO_INCREMENT,
  nom_ubic VARCHAR(255) NOT NULL,
  Chip_ID TEXT,
  valor_hum INT(11),
  valor tem INT(11) PRIMARY KEY AUTO_INCREMENT,
  Hora TIME,
);

DESCRIBE task;