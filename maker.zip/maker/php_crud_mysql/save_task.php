<?php
// inclumos la conexión a la base de datos 
include('db.php');

if (isset($_POST['save_task'])) {
  // con el metodo post nos guarda los datos en nuestra base de datos y con los corchetes y las comillas les indicamos en el columna se debe ubicar cada uno
  $nom_ubic = $_POST['nom_ubic'];
  $Chip_ID = $_POST['Chip_ID'];
  $Cantidad = $_POST['Cantidad'];
  $valor_tem = $_POST['valor_tem'];
  $valor_hum = $_POST['valor_hum'];
  // Insert es un metodo de SQL para insertar en la tabla de la base de datos
  $query = "INSERT INTO tempdia(nom_ubic, Chip_ID,Cantidad,valor_tem,valor_hum) VALUES ('$nom_ubic', '$Chip_ID','$Cantidad','$valor_tem','$valor_hum')";
  $result = mysqli_query($conn, $query);
  // Si algo en la parte anterior nos da un error el resultado sera fallido
  if(!$result) {
    die("Fallido");
  }
  // Se imprime como mensaje que guardamos correctamente los datos 
  $_SESSION['message'] = 'Se guardo exitosamente los datos';
  $_SESSION['message_type'] = 'success';
  // especificamos la localizacion del index de php
  header('Location: index.php');

}

?>