
<!-- include quiere decir que incluye los siguientes archivos entre parentesis con comillas se encuentran las rutas de los archivos

  <?php include("db.php"); ?>

<?php include('includes/header.php'); ?>
<main class="container p-4">
  <div class="row">
    <div class="col-md-4">
      <!-- MESSAGES -->
      <?php if (isset($_SESSION['message'])) { ?>
      <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <?php session_unset(); } ?>

      <!-- Formulario de html con cada una de las variables asiganandoles nombres desde la variable name -->
      <div class="card card-body">
        <form action="save_task.php" method="POST">
          <div class="form-group">
            <input type="text" name="nom_ubic" class="form-control" placeholder=" Nombre " autofocus>
          </div>
          <div class="form-group">
            <textarea name="Chip_ID" rows="2" class="form-control" placeholder="Celular"></textarea>
          </div>
          <div class="form-group">
            <input type="text" name="Cantidad" class="form-control" placeholder="Cantidad" autofocus>
          </div>
          <div class="form-group">
            <input type="text" name="valor_tem" class="form-control" placeholder="Descripción" autofocus>
          </div>
          <div class="form-group">
            <input type="text" name="valor_hum" class="form-control" placeholder="Valor total" autofocus>
          </div>
          <!-- save task es un metodo de guardar lo de php en la base de datos-->
          <input type="submit" name="save_task" class="btn btn-success btn-block" value="Guardar cotización">
        </form>
      </div>
    </div>
    <div class="col-md-8">
      <table class="table table-bordered">
        <thead>
          <tr>
            <!-- nombre de las variables lo cual aparecera en pantalla  -->
            <th>Nombre</th>
            <th>Celular</th>
            <th>Cantidad</th>
            <th>Descripción</th>
            <th>Valor total</th>
          </tr>
        </thead>
        <tbody>
          
          <?php
          // seleccionamos una base de datos con codigo sql con la cual buscaremos la tabla tempdia 
          $query = "SELECT * FROM tempdia";
          $result_tasks = mysqli_query($conn, $query);    

          while($row = mysqli_fetch_assoc($result_tasks)) { ?>
          <tr>
            <!-- echo nos muestra en pantalla desde la base de datos los datos que se encuentran en esta -->
            <td><?php echo $row['nom_ubic']; ?></td>
            <td><?php echo $row['Chip_ID']; ?></td>
            <td><?php echo $row['Cantidad']; ?></td>
            <td><?php echo $row['valor_tem']; ?></td>
            <td><?php echo $row['valor_hum']; ?></td>
            <td>
              <!-- Estan las dos opciones de editar o eliminar los datos y con los href nos refenciamos a las paginas de php que cremos -->
              <a href="edit.php?id=<?php echo $row['id']?>" class="btn btn-secondary">
                <i class="fas fa-marker"></i>
              </a>
              <a href="delete_task.php?id=<?php echo $row['id']?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
              </a>
            </td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</main>
<!-- Nos incluye y referencia los scripts que usamos para el estilo de la pagina web -->
<?php include('includes/footer.php'); ?>