<?php
// inclumos la base de datos 
include("db.php");
// nombramos nuestras primeras variables 
$nom_ubic =  '';
$Chip_ID =  '';
$Cantidad = '';
$valor_tem = '';
$valor_hum = '';

if  (isset($_GET['id'])) {
  $id = $_GET['id'];
  // seleccionamos y buscamos con el id mediante codigo SQL 
  $query = "SELECT * FROM tempdia WHERE id=$id";
  $result = mysqli_query($conn, $query);
  // si los resultados de la busqueda estan bien se seguira 
  if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_array($result);
    // sale una ventana emergente para la modificacion de la pagina,debemos nombrar y seleccionar cada una de las columnas 
    $nom_ubic =  $row['nom_ubic'];
    $Chip_ID =  $row['Chip_ID'];
    $Cantidad =  $row['Cantidad'];
    $valor_tem = $row['valor_tem'];
    $valor_hum = $row['valor_hum'];
  }
}
// mediante el metodo update se sobreescribiran las palabras es decir que habra un reemplazo 
if (isset($_POST['update'])) {
  $id = $_GET['id'];
  $nom_ubic = $_POST['nom_ubic'];
  $Chip_ID = $_POST['Chip_ID'];
  $cantidad = $_POST['Cantidad'];
  $valor_tem = $_POST['valor_tem'];
  $valor_hum = $_POST['valor_hum'];
  // ubicamos y seleccionamos cada una de las variables con las variables de SQL 
  $query = "UPDATE tempdia set nom_ubic = '$nom_ubic', Chip_ID = '$Chip_ID',Cantidad = '$Cantidad',valor_tem = '$valor_tem', valor_hum = '$valor_hum' WHERE id=$id";
  mysqli_query($conn, $query);
  // si sale todo correcto saldra un mensaje de actualizado correctamente 
  $_SESSION['message'] = 'Actualizado correctamente';
  $_SESSION['message_type'] = 'warning';
  header('Location: index.php');
}

?>
<?php include('includes/header.php'); ?>
<!-- se actualizara ademas de la base de datos se actualiza la pagina principal --> 
<div class="container p-4">
  <div class="row">
    <div class="col-md-4 mx-auto">
      <div class="card card-body">
      <form action="edit.php?id=<?php echo $_GET['id']; ?>" method="POST">
        <div class="form-group">
          <input name="nom_ubic" type="text" class="form-control" value="<?php echo $nom_ubic; ?>" placeholder="Update nom_ubic">
        </div>
        <div class="form-group">
        <textarea name="Chip_ID" class="form-control" cols="30" rows="10"><?php echo $Chip_ID;?></textarea>
        </div>
        <div class="form-group">
          <input name="Cantidad" type="text" class="form-control" value="<?php echo $Cantidad; ?>" placeholder="Update Cantidad">
        </div>
        <div class="form-group">
          <input name="valor_tem" type="text" class="form-control" value="<?php echo $valor_tem; ?>" placeholder="Update valor_tem">
        </div>
        <div class="form-group">
          <input name="valor_hum" type="text" class="form-control" value="<?php echo $valor_hum; ?>" placeholder="Update valor_hum">
        </div>
        <button class="btn-success" name="update">
          Update
</button>
      </form>
      </div>
    </div>
  </div>
</div>
<?php include('includes/footer.php'); ?>