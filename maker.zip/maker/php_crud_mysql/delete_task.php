<?php
// Incluimos la conexión con la base de datos 
include("db.php");

if(isset($_GET['id'])) {
  // con el metodo get seleccionamos la columna id 
  $id = $_GET['id'];
  // mediante codigo SQL le decimos que borre la fila con el numero  del id 
  $query = "DELETE FROM tempdia WHERE id = $id";
  $result = mysqli_query($conn, $query);
  // Si algo sale error en los anterior saldra un mensaje de fallido 
  if(!$result) {
    die("fallido");
  }
  // Si todo funciono bien estara el mensaje de eliminado correctamente 
  $_SESSION['message'] = 'Eliminado correctamente';
  $_SESSION['message_type'] = 'danger';
  header('Location: index.php');
}

?>